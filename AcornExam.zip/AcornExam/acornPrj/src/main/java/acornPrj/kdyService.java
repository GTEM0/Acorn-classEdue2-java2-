package acornPrj;

import java.util.ArrayList;

public class kdyService {
	
	kdyDAO dao = new kdyDAO();
	public ArrayList<kdy> selectAll(){ 
	
	ArrayList<kdy> list = dao.selectAll();
	return list;
	}
}
